function getPageText() {
  const body = document.body;
  let text = body ? body.innerText || '' : '';
  if (text.length > 10000) {
    text = text.slice(0, 10000);
  }
  return text;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'getPageText') {
    sendResponse({ text: getPageText() });
  }
});
