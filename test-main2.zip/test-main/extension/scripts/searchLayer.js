export async function searchDuckDuckGo(query) {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('DuckDuckGo request failed');
  return res.json();
}

export async function searchGoogleHTML(query, lang = 'ru') {
  const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&hl=${lang}&num=10&sourceid=chrome`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Google request failed');
  const text = await res.text();
  const parser = new DOMParser();
  const doc = parser.parseFromString(text, 'text/html');
  // Google markup changes frequently; selectors may need updates
  const snippets = [
    ...doc.querySelectorAll('div[data-sncf="1"], div[data-content-feature="1"], div[data-attrid="wa:/description"]')
  ].map(el => el.textContent.trim());
  return snippets;
}

export async function fetchWikipediaSummary(lang, title) {
  const url = `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Wikipedia request failed');
  return res.json();
}

export async function handleClaimDetection(claim) {
  // Simple implementation: aggregate evidence from all sources
  const ddg = await searchDuckDuckGo(claim);
  const google = await searchGoogleHTML(claim);
  const wiki = await fetchWikipediaSummary('ru', claim);
  const evidence = [];
  if (ddg.AbstractText) {
    evidence.push({
      fragment: ddg.AbstractText,
      url: ddg.AbstractURL,
      title: ddg.Heading
    });
  }
  google.slice(0, 3).forEach(fragment => {
    evidence.push({
      fragment,
      url: 'https://www.google.com',
      title: 'Google'
    });
  });
  if (wiki.extract) {
    evidence.push({
      fragment: wiki.extract,
      url: wiki.content_urls?.desktop?.page,
      title: wiki.title
    });
  }
  return evidence;
}
